from with_test import test, test_case, get_test_self

__author__ = 'Colin Ji'
__versioninfo__ = (0, 2, 1)
__version__ = '.'.join(map(str, __versioninfo__))

__all__ = ['test', 'test_case', 'get_test_self']
